package com.db;

import java.util.List;

public class TransactionList {

	private List<Dummytransaction> transactionList;

	public List<Dummytransaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(List<Dummytransaction> transactionList) {
		this.transactionList = transactionList;
	}
	
}
